# leto-checker
A simply python script to check whether or not Artemis' Umbrella has suffered a critical existence failure.
